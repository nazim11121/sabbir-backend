<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class TDashboardTodoList extends Model
{
    protected $guarded = ['id'];
}
