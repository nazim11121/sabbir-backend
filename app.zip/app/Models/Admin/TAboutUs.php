<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class TAboutUs extends Model
{
    protected $guarded = [];
}
