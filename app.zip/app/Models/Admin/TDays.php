<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class TDays extends Model
{
    protected $guarded = [];
}
