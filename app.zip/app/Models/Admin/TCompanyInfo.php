<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class TCompanyInfo extends Model
{
    protected $guarded = [];
}
