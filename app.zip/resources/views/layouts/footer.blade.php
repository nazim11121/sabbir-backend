<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">N&N Co.</a> {{ date('Y') }}</p>
        <!-- <p>Distributed by <a href="https://analyzenbd.com/" target="_blank">N&N Co.</a></p> -->
    </div>
</div>
</div>

<script src="{{ asset('assets/vendor/global/global.min.js') }}"></script>
<script src="{{ asset('assets/js/quixnav-init.js') }}"></script>
<script src="{{ asset('assets/js/custom.min.js') }}"></script>


<!-- Vectormap -->
<script src="{{ asset('assets/vendor/raphael/raphael.min.js') }}"></script>
<script src="{{ asset('assets/vendor/morris/morris.min.js') }}"></script>


<script src="{{ asset('assets/vendor/circle-progress/circle-progress.min.js') }}"></script>
<script src="{{ asset('assets/vendor/chart.js/Chart.bundle.min.js') }}"></script>

<script src="{{ asset('assets/vendor/chartist/js/chartist.min.js') }}"></script>
<script src="{{ asset('assets/vendor/moment/moment.min.js') }}"></script>
<script src="{{ asset('assets/vendor/pg-calendar/js/pignose.calendar.min.js') }}"></script>
<script src="{{ asset('assets/js/dashboard/dashboard-2.js') }}"></script>

<script src="{{ asset('assets/vendor/gaugeJS/dist/gauge.min.js') }}"></script>

<!--  flot-chart js -->
<script src="{{ asset('assets/vendor/flot/jquery.flot.js') }}"></script>
<script src="{{ asset('assets/vendor/flot/jquery.flot.resize.js') }}"></script>

<!-- Owl Carousel -->
<script src="{{ asset('assets/vendor/owl-carousel/js/owl.carousel.min.js') }}"></script>

<!-- Counter Up -->
<script src="{{ asset('assets/vendor/jqvmap/js/jquery.vmap.min.js') }}"></script>
<script src="{{ asset('assets/vendor/jqvmap/js/jquery.vmap.usa.js') }}"></script>
<script src="{{ asset('assets/vendor/jquery.counterup/jquery.counterup.min.js') }}"></script>

<script src="{{ asset('assets/js/dashboard/dashboard-1.js') }}"></script>

<script src="{{ 'assets/js/styleSwitcher.js' }}"></script>
<script src="{{ 'assets/vendor/jqueryui/js/jquery-ui.min.js' }}"></script>
<script src="{{ 'assets/vendor/fullcalendar/js/fullcalendar.min.js' }}"></script>
<script src="{{ 'assets/js/plugins-init/fullcalendar-init.js' }}"></script>
<!-- Chartlist -->
<script src="{{ asset('assets/vendor/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js') }}"></script>
<!-- Flot -->
<script src="{{ asset('assets/vendor/flot/jquery.flot.js') }}"></script>
<script src="{{ asset('assets/vendor/flot/jquery.flot.pie.js') }}"></script>
<script src="{{ asset('assets/vendor/flot/jquery.flot.resize.js') }}"></script>
<script src="{{ asset('assets/vendor/flot-spline/jquery.flot.spline.min.js') }}"></script>
<!-- Init file -->
<script src="{{ asset('assets/js/plugins-init/widgets-script-init.js') }}"></script>
<!-- Chart-flot -->
<script src="{{ asset('assets/vendor/flot/jquery.flot.js') }}"></script>
<script src="{{ asset('assets/vendor/flot/jquery.flot.pie.js') }}"></script>
<script src="{{ asset('assets/vendor/flot/jquery.flot.resize.js') }}"></script>
<script src="{{ asset('assets/vendor/flot-spline/jquery.flot.spline.min.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/flot-init.js') }}"></script>
<!-- Chart Morris plugin files -->
<script src="{{ asset('assets/vendor/raphael/raphael.min.js') }}"></script>
<script src="{{ asset('assets/vendor/morris/morris.min.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/morris-init.js') }}"></script>
<!-- Chart ChartJS plugin files -->
<script src="{{ asset('assets/vendor/chart.js/Chart.bundle.min.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/chartjs-init.js') }}"></script>
<!-- Chart Chartist plugin files -->
<script src="{{ asset('assets/vendor/chartist/js/chartist.min.js') }}"></script>
<script src="{{ asset('assets/vendor/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/chartist-init.js') }}"></script>

<!-- chart sparkline -->
<script src="{{ asset('assets/vendor/peity/jquery.peity.min.js') }}"></script>
<!-- Chart sparkline plugin files -->
<script src="{{ asset('assets/vendor/jquery-sparkline/jquery.sparkline.min.js') }}"></script>
<!-- Easy pie chart plugin files -->
<script src="{{ asset('assets/vendor/easy-pie-chart/jquery.easypiechart.min.js') }}"></script>
<!-- Circle progress -->

<script src="{{ asset('assets/vendor/flot/jquery.flot.js') }}"></script>
<script src="{{ asset('assets/vendor/flot/jquery.flot.pie.js') }}"></script>
<script src="{{ asset('assets/vendor/flot/jquery.flot.resize.js') }}"></script>
<script src="{{ asset('assets/vendor/flot-spline/jquery.flot.spline.min.js') }}"></script>

<script src="{{ asset('assets/vendor/amcharts/amcharts.js') }}"></script>
<script src="{{ asset('assets/vendor/amcharts/serial.js') }}"></script>
<script src="{{ asset('assets/vendor/amcharts/plugins/dataloader.min.js') }}"></script>
<script src="{{ asset('assets/vendor/amcharts/plugins/export.min.js') }}"></script>
<script src="{{ asset('assets/vendor/amcharts/ammap.js') }}"></script>
<script src="{{ asset('assets/vendor/amcharts/worldLow.js') }}"></script>
<script src="{{ asset('assets/vendor/amcharts/pie.js') }}"></script>
<script src="{{ asset('assets/vendor/amcharts/amstock.js') }}"></script>

<script src="{{ asset('assets/js/plugins-init/amchart-init.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/chartjs-init.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/chartist-init.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/morris-init.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/sparkline-init.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/easy-pie-chart-init.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/flot-init.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/piety-init.js') }}"></script>
<!-- Summernote -->
<script src="{{ asset('assets/vendor/summernote/js/summernote.min.js') }}"></script>
<!-- Summernote init -->
<script src="{{ asset('assets/js/plugins-init/summernote-init.js') }}"></script>
<!-- Datatable -->
<script src="{{ asset('assets/vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/datatables.init.js') }}"></script>
<!-- Select2 -->
<script src="{{ asset('assets/vendor/select2/js/select2.full.min.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/select2-init.js') }}"></script>
<!-- Nestable -->
<script src="{{ asset('assets/vendor/nestable2/js/jquery.nestable.min.js') }}"></script>
<!-- All init script -->
<script src="{{ asset('assets/js/plugins-init/nestable-init.js') }}"></script>
<!-- Nou slider -->
<script src="{{ asset('assets/vendor/nouislider/nouislider.min.js') }}"></script>
<script src="{{ asset('assets/vendor/wnumb/wNumb.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/nouislider-init.js') }}"></script>
<!-- Sweet alert -->
{{-- <script src="{{ asset('assets/vendor/sweetalert2/dist/sweetalert2.min.js') }}"></script> --}}
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="{{ asset('assets/js/plugins-init/sweetalert.init.js') }}"></script>
<!-- Toastr -->
<script src="{{ asset('assets/vendor/toastr/js/toastr.min.js') }}"></script>
<!-- All init script -->
<script src="{{ asset('assets/js/plugins-init/toastr-init.js') }}"></script>
<!-- Flasher -->
<script src="{{ asset('assets/vendor/flasher/flasher.min.js') }}"></script>
<!-- Vectormap -->
<script src="{{ asset('assets/vendor/jqvmap/js/jquery.vmap.min.js') }}"></script>
<script src="{{ asset('assets/vendor/jqvmap/js/jquery.vmap.world.js') }}"></script>
<script src="{{ asset('assets/vendor/jqvmap/js/jquery.vmap.usa.js') }}"></script>
<!-- All init script -->
<script src="{{ asset('assets/js/plugins-init/jqvmap-init.js') }}"></script>
<!-- Load script form view  -->

{{-- ck editor --}}
<script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>


<script>
    document.querySelectorAll('.editor').forEach((item) => {
        CKEDITOR.replace(item);
    });
</script>

@stack('script')
<script>
    @if (session('success'))
        toastr.success("{{ session('success') }}");
    @elseif (session('error'))
        toastr.error("{{ session('error') }}");
    @elseif (session('info'))
        toastr.info("{{ session('info') }}");
    @elseif (session('warning'))
        toastr.warning("{{ session('warning') }}");
    @elseif (session('danger'))
        toastr.warning("{{ session('danger') }}");
    @endif
</script>
</body>

</html>
