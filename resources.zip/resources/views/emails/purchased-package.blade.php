<!DOCTYPE html>
<html>
<head>
    <title>Purchase package notify</title>
</head>
<body>
    <p>প্রিয়, {{ $user->name }}</p>
    <p>আপনার BD Funded Trader অ্যাকাউন্টের জন্য নির্বাচিত প্যাকেজটি সফলভাবে ক্রয় ও সক্রিয় হয়েছে।</p>
    <p>আপনার সুবিধাগুলো ব্যবহার করতে এখনই লগইন করুন:</p>
    <p>🔗https://bdfundedtrader.com/login অ্যাকাউন্টে লগইন করুন</p>
    <p>আপনার Quotext Account Login Credentials:</p>
    <p>username: {{ $user->mailAccount->username ?? '' }}<p>
    <p>password: {{ $user->mailAccount->quotex_password ?? '' }}<p>
    <p>যেকোনো সহায়তার জন্য আমাদের সাপোর্ট টিম সর্বদা প্রস্তুত। আপনার ট্রেডিং যাত্রায় BD Funded Trader এর পক্ষ থেকে রইল আন্তরিক শুভকামনা।</p>
    <br>
    <p>শুভেচ্ছান্তে, <br>{{ config('app.name') }} সাপোর্ট টিম</p>
</body>
</html>







